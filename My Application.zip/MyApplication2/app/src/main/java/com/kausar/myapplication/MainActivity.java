package com.kausar.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;

public class MainActivity extends AppCompatActivity {

    private Minefield minefield;
    private Button[][] buttons; // Buttons representing the cells
    private int size = 8; // Change the size of the grid as needed
    private int mines = 10; // Change the number of mines as needed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Initialize the minefield
        minefield = new Minefield(size, mines);

        // Initialize the grid of buttons
        buttons = new Button[size][size];
        GridLayout gridLayout = findViewById(R.id.gridLayout);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                buttons[i][j] = new Button(this);
                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.height = 100; // Set button size as needed
                params.width = 100;
                params.rowSpec = GridLayout.spec(i);
                params.columnSpec = GridLayout.spec(j);
                buttons[i][j].setLayoutParams(params);
                buttons[i][j].setText("");
                buttons[i][j].setOnClickListener(cellClickListener(i, j));
                gridLayout.addView(buttons[i][j]);
            }
        }
    }

    private View.OnClickListener cellClickListener(final int x, final int y) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int value = minefield.getCell(x, y);
                // Check if it's a mine
                if (value == -1) {
                    // Handle game over
                    buttons[x][y].setText("M"); // Set "M" for mine
                    // Implement game over logic here
                } else {
                    // Set the value of the cell
                    buttons[x][y].setText(String.valueOf(value));
                    // Check for 0 value, reveal neighboring cells if 0
                    if (value == 0) {
                        // Implement logic to reveal neighboring cells
                        // Recursively reveal neighboring cells if the value is 0
                    }
                }
            }
        };
    }
}